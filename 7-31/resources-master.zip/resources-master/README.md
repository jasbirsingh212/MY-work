# Resources
1. New icons : Icons for whiteboard application
2. service-master: Data that would feed our react application
